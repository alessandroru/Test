using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class State
{
    protected FiniteStateMachine stateMachine;
    protected Entity entity;
    protected Core core;

    public float startTime { get; protected set; }

    protected string animBollName;

    public State(Entity entity, FiniteStateMachine stateMachine, string animBollName)
    {
        this.entity = entity;
        this.stateMachine = stateMachine;
        this.animBollName = animBollName;
        core = entity.Core;
    }

    public virtual void Enter()
    {
        startTime = Time.time;
        entity.anim.SetBool(animBollName, true);
        DoChecks();
    }

    public virtual void Exit()
    {
        entity.anim.SetBool(animBollName, false);
    }

    public virtual void LogicUpdate()
    {

    }

    public virtual void PhysicsUpdate()
    {
        DoChecks();
    }

    public virtual void DoChecks()
    {

    }
}
