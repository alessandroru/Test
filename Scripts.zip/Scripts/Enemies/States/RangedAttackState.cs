using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RangedAttackState : AttackState
{
    protected D_RangedAttack stateDate;

    protected GameObject projectile;
    protected Projectile projectileScript;

    public RangedAttackState(Entity entity, FiniteStateMachine stateMachine, string animBollName, Transform attackPosition, D_RangedAttack stateDate) : base(entity, stateMachine, animBollName, attackPosition)
    {
        this.stateDate = stateDate;
    }

    public override void Enter()
    {
        base.Enter();
    }

    public override void Exit()
    {
        base.Exit();
    }

    public override void FinishAttack()
    {
        base.FinishAttack();
    }

    public override void LogicUpdate()
    {
        base.LogicUpdate();
    }

    public override void PhysicsUpdate()
    {
        base.PhysicsUpdate();
    }

    public override void TriggerAttack()
    {
        base.TriggerAttack();

        projectile = GameObject.Instantiate(stateDate.projectile, attackPosition.position, attackPosition.rotation);
        projectileScript = projectile.GetComponent<Projectile>();

        projectileScript.FireProjectile(stateDate.projectileSpeed, stateDate.projectileTravelDistance, stateDate.projectileDamage);
    }
}
